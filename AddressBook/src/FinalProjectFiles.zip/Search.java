
public interface Search {
	public void searchFName(String value);
	public void searchLName(String value);
	public void searchPhnNum(String value);
	public void searchEmail(String value);
}
